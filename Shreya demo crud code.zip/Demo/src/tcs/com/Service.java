package tcs.com;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;

import javax.swing.text.html.HTMLDocument.Iterator;

public class Service {
	
	public static void main(String[] args) throws ParseException {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your choice");
		System.out.println("1---read");
		System.out.println("2---create");
		System.out.println("3---update");
		System.out.println("4---delete");
		
		int a=sc.nextInt();
		Date d1=new Date(1996-12-21);
		Date d2=new Date(1990-12-25);
		Behaviour bh=new Behaviour(1,21,"shreya",6786788,d1,(float) 25662.22);		
		Behaviour bh1=new Behaviour(5,11,"kundan",6211288,d2,(float) 5313131.22);	
		ArrayList<Behaviour>list=new ArrayList<Behaviour>();
		
		
	list.add(bh);
	list.add(bh1);
		if(a==1)
		{
		Read(list);
		for(Behaviour c:list)
		{
			System.out.println(c.getId()+" "+c.getAge()+" "+c.getName()+" "+c.getPhoneNo()+" "+c.getSalary()+" "+c.getDOB());
		}
		}
		else if(a==2)
		{
			Behaviour[]arr=Create(list);
			for(Behaviour c: arr)
			{
			System.out.println(c.getId()+" "+c.getAge()+" "+c.getName()+" "+c.getPhoneNo()+" "+c.getSalary()+" "+c.getDOB());
				
			}
			Collections.addAll(list,arr);
		for(Behaviour c:list)
		{
			System.out.println(c.getId()+" "+c.getAge()+" "+c.getName()+" "+c.getPhoneNo()+" "+c.getSalary()+" "+c.getDOB());
			
		}
			}
		else if(a==3)
		{
			Delete(list);
			
		}
		else
		{
			System.out.println("fdsg");
		}
		
	}
	public static ArrayList<Behaviour>Read(ArrayList<Behaviour> sh)
	{
		return sh;
		
	}
	public static Behaviour[] Create(ArrayList<Behaviour> list) throws ParseException 
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the no of data to be inserted :");
		int num=sc.nextInt();
		System.out.println("enter the details in the following formats as specified:");
		Behaviour[] newArray=new Behaviour[num];
		ArrayList<Behaviour>arr=new ArrayList<Behaviour>();
         for(int i=0;i<num;i++)
         {
		int a=sc.nextInt();
		int age=sc.nextInt();
		sc.nextLine();
		String name=sc.nextLine();
		long w=sc.nextLong();
		sc.nextLine();
		String date=sc.nextLine();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy/mm/dd");
		java.util.Date Dtae = sdf.parse(date);
		/*SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-mm-dd");
		Date x=sdf1.format(Dtae);*/
		
		float w1=sc.nextFloat();
		newArray[i]=new Behaviour(a,age,name,w,Dtae,w1);
          }
         return newArray;
		}	
		
		public static void Delete(ArrayList<Behaviour> list)
		{
			Scanner sc=new Scanner(System.in);
			for(Behaviour c:list)
			{

				System.out.println(c.getId()+" "+c.getAge()+" "+c.getName()+" "+c.getPhoneNo()+" "+c.getSalary()+" "+c.getDOB());
				
			}
			
			System.out.println("enter the id you want to delete:");
			int id=sc.nextInt();
			java.util.Iterator<Behaviour> itr =list.iterator();
			while(itr.hasNext())
				
			{
				if(list.contains(id))
				{
                      list.removeAll(list);
				}
			}
			
                      for(Behaviour c :list)
                      {
						System.out.println(c.getId()+" "+c.getAge()+" "+c.getName()+" "+c.getPhoneNo()+" "+c.getSalary()+" "+c.getDOB());
						
					}
				}
}
		
			
			
			
			
		
		
	
	
	

